package victor.donet.peluqueria.maida.clases;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import javax.swing.JOptionPane;

public class BaseDatos {
	private Connection con;
	private ResultSet resultado;

	public BaseDatos(){
		this.abrir_db();
//		this.setResultado(consultar_db("SELECT * FROM Clientes"));
	}
	
	// Abrimos la base de datos dejamos abierto ResultSet y Connection.
	private void abrir_db(){
		System.out.println("ABRIENDO BASE DE DATOS");
		try	{
			System.out.println("Class.forName(sun.jdbc.odbc.JdbcOdbcDriver)");
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			String url = "jdbc:odbc:Driver={Microsoft Access Driver (*.mdb, *.accdb)};DBQ=C:\\Perruqueria\\Perruqueria.mdb";
			System.out.println("con = DriverManager.getConnection(url)");
			con = DriverManager.getConnection(url);
			System.out.println("BASE DE DATOS ABIERTA");
		}
		catch(ClassNotFoundException ex){
			JOptionPane.showMessageDialog(null, "ClassNotFoundException abrir_db(): No se logr� establecer conexi�n con la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
		}
		catch(SQLException ex){
			JOptionPane.showMessageDialog(null, "SQLException abrir_db(): No se logr� establecer conexi�n con la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}

	// Cerramos la base de datos, (cerrando ResultSet y Connection).
	public void cerrar_db(){
		System.out.println("CERRANDO BASE DE DATOS");
		try{
			resultado.close();
		} catch(SQLException ex){
			JOptionPane.showMessageDialog(null, "cerrar_db(): No se logr� establecer conexi�n con la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
		}

		try	{
			con.close();
		} catch(SQLException ex){
			JOptionPane.showMessageDialog(null, "cerrar_db(): No se logr� establecer conexi�n con la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
		}
		System.out.println("BASE DE DATOS CERRADA");
	}

	// Realizamos la consulta a la base de datos.
	public ResultSet consultar_db(String sql){
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		System.out.println("consultar_db("+sql+")");
		try	{
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			pstmt.close();
		}
		catch(SQLException errSql){
			JOptionPane.showMessageDialog(null, "consultar_db(sql): No se logr� establecer conexi�n con la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
		} 
		System.out.println("FIN consultar_db");
		return rs;
	}

	// Accedemos al siguiente registro del conjunto de resultados del select cliente
	public Cliente nextRecord(ResultSet rs){
		System.out.println("nextRecord(rs)");
		Cliente cli = null;
		try	{
			rs.next();
			cli = asignarCliente(rs);
		}
		catch(SQLException errSql){
			JOptionPane.showMessageDialog(null, "nextRecord(rs): No se logr� establecer conexi�n con la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
		}
		System.out.println("FIN nextRecord(rs)");
		return cli;
	}

	// Accedemos al anterior registro del conjunto de resultados del select cliente
	public Cliente prevRecord(ResultSet rs){
		System.out.println("prevRecord(rs)");
		Cliente cli = null;
		try	{
			rs.previous();
			cli = asignarCliente(rs);
		}
		catch(SQLException errSql){
			JOptionPane.showMessageDialog(null, "prevRecord(rs): No se logr� establecer conexi�n con la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
		}
		System.out.println("FIN prevRecord(rs)");
		return cli;
	}

	// Insertamos un registro en la tabla de clientes
	public void insertar_Cliente_db(Cliente cli){
		System.out.println("insertar_Cliente_db(cli)");
		PreparedStatement pstmt=null;
		try	{
			String sql = "INSERT INTO Clientes('Nombre','Apellidos','NIF','Sexo','Direccion','Poblacion','CPostal','TelFijo','Movil','email','FechaNac') VALUES" + "(?,?,?,?,?,?,?,?,?,?,?)";
			pstmt = con.prepareStatement(sql);
			pstmt.setString(1, cli.getNombre());
			pstmt.setString(2, cli.getApellidos());
			pstmt.setString(3, cli.getDni());
			pstmt.setString(4, cli.getSexo());
			pstmt.setString(5, cli.getDireccion());
			pstmt.setString(6, cli.getPoblacion());
			pstmt.setString(7, cli.getcPostal());
			pstmt.setString(8, cli.getTelefono());
			pstmt.setString(9, cli.getMovil());
			pstmt.setString(10, cli.getEmail());
			pstmt.setDate(11, (java.sql.Date) cli.getNacimiento());			
			pstmt.executeUpdate();
			pstmt.close();
		}
		catch(SQLException errSql){
			JOptionPane.showMessageDialog(null, "insertar_Cliente_db(cli): No se logr� establecer conexi�n con la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
		}
		System.out.println("FIN insertar_Cliente_db");
	}
	
	// Insertamos un registro en la tabla de Tintes
	public void insertar_TinteCliente_db(ClienteTintes tinte){
		PreparedStatement pstmt = null;
		String sql = "INSERT INTO Tintes('idCliente','Tinte','Color','Observaciones') VALUES(?,?,?,?)";
		try	{
			pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, tinte.getIdCliente());
			pstmt.setString(2, tinte.getTinte());
			pstmt.setString(3, tinte.getColor());
			pstmt.setString(4, tinte.getObservaciones());
			pstmt.executeUpdate();
			pstmt.close();
		}
		catch(SQLException errSql){
			JOptionPane.showMessageDialog(null, "insertar_TinteCliente_db(tinte): No se logr� establecer conexi�n con la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
		}
	}
	
	// Asignamos los datos del ResultSet a la clase Cliente.
	public Cliente asignarCliente(ResultSet result){
		Cliente clienteNuevo = null;
		try {
			String nombre = (String) result.getString(1);
			String apellidos = (String) result.getString(2);
			String dni = (String) result.getString(3);
			String sexo = (String) result.getString(4);
			String direccion = (String) result.getString(5);
			String poblacion = (String) result.getString(6);
			String cpostal = (String) result.getString(7);
			String telf = (String) result.getString(8);
			String movil = (String) result.getString(9);
			String email = (String) result.getString(10);
			Date nacimiento = (Date) result.getDate(12);
			Date alta = (Date) result.getDate(13);
			clienteNuevo = new Cliente(nombre, apellidos, dni, sexo, direccion, poblacion, cpostal, telf, movil, email, nacimiento, alta);
		}catch(SQLException ex){
			JOptionPane.showMessageDialog(null, "asignarCliente(rs): No se logr� establecer conexi�n con la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
		}
		return clienteNuevo;
	}

	// Asignamos los datosdel ResultSet a la clase CienteTintes
	public ClienteTintes asignarTinte(ResultSet result){
		ClienteTintes tinteNuevo = null;
		try {
			int idTinte = (int) result.getInt(1);
			int idCliente = (int) result.getInt(2);
			Date fechaTinte = (Date) result.getDate(3);
			String nomTinte = (String) result.getString(4);
			String colorTinte = (String) result.getString(5);
			String observaciones = (String) result.getString(6);
			tinteNuevo = new ClienteTintes(idTinte, idCliente, fechaTinte, nomTinte, colorTinte, observaciones);
		}catch(SQLException ex){
			JOptionPane.showMessageDialog(null, "asignarTinte(): No se logr� establecer conexi�n con la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
		}
		return tinteNuevo;
	}

	public ResultSet getResultado() {
		return resultado;
	}

	public void setResultado(ResultSet res) {
		this.resultado = res;
	}

}
