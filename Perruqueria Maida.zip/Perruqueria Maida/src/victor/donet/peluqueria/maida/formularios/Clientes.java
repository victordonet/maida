package victor.donet.peluqueria.maida.formularios;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import victor.donet.peluqueria.maida.clases.BaseDatos;
import victor.donet.peluqueria.maida.clases.Cliente;
import org.eclipse.wb.swing.FocusTraversalOnArray;
import java.awt.Component;

public class Clientes extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField tfNombre;
	private JTextField tfApellidos;
	private JTextField tfNIF;
	private JTextField tfEmail;
	private JTextField tfDireccion;
	private JTextField tfCPostal;
	private JTextField tfPoblacion;
	private JTextField tfMovil;
	private JTextField tfTelefono;
	private JTextField tfNacimiento;
	private JComboBox<String> cbSexo;
	private BaseDatos bd = null;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Clientes frame = new Clientes();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Clientes() {
		bd = new BaseDatos();
		setIconImage(Toolkit.getDefaultToolkit().getImage(Clientes.class.getResource("/victor/donet/peluqueria/maida/imagenes/Profile.png")));
		setTitle("Perruqueria Maida - Alta de Clients");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 600, 400);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(154, 205, 50));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNombre = new JLabel("Nom:");
		lblNombre.setFont(new Font("Verdana", Font.PLAIN, 14));
		lblNombre.setBounds(9, 38, 64, 23);
		contentPane.add(lblNombre);
		
		tfNombre = new JTextField();
		tfNombre.setFont(new Font("Verdana", Font.PLAIN, 14));
		tfNombre.setBounds(96, 38, 176, 23);
		contentPane.add(tfNombre);
		tfNombre.setColumns(10);
		
		JLabel lblApellidos = new JLabel("Cognoms:");
		lblApellidos.setFont(new Font("Verdana", Font.PLAIN, 14));
		lblApellidos.setBounds(288, 38, 79, 23);
		contentPane.add(lblApellidos);
		
		tfApellidos = new JTextField();
		tfApellidos.setFont(new Font("Verdana", Font.PLAIN, 14));
		tfApellidos.setBounds(377, 38, 195, 23);
		contentPane.add(tfApellidos);
		tfApellidos.setColumns(10);
		
		JLabel lblNif = new JLabel("NIF:");
		lblNif.setFont(new Font("Verdana", Font.PLAIN, 14));
		lblNif.setBounds(9, 90, 46, 23);
		contentPane.add(lblNif);
		
		tfNIF = new JTextField();
		tfNIF.setFont(new Font("Verdana", Font.PLAIN, 14));
		tfNIF.setBounds(64, 90, 94, 23);
		contentPane.add(tfNIF);
		tfNIF.setColumns(10);
		
		JLabel lblSexo = new JLabel("Sexe:");
		lblSexo.setFont(new Font("Verdana", Font.PLAIN, 14));
		lblSexo.setBounds(167, 90, 46, 23);
		contentPane.add(lblSexo);
		
		cbSexo = new JComboBox<String>();
		cbSexo.addItem("Hombre");
		cbSexo.addItem("Mujer");
		cbSexo.setFont(new Font("Verdana", Font.PLAIN, 14));
		cbSexo.setBounds(222, 90, 94, 23);
		contentPane.add(cbSexo);
		
		JLabel lblEmail = new JLabel("email:");
		lblEmail.setFont(new Font("Verdana", Font.PLAIN, 14));
		lblEmail.setBounds(325, 90, 46, 23);
		contentPane.add(lblEmail);
		
		tfEmail = new JTextField();
		tfEmail.setFont(new Font("Verdana", Font.PLAIN, 14));
		tfEmail.setBounds(380, 90, 192, 23);
		contentPane.add(tfEmail);
		tfEmail.setColumns(10);
		
		JLabel lblDireccin = new JLabel("Direcci\u00F3:");
		lblDireccin.setFont(new Font("Verdana", Font.PLAIN, 14));
		lblDireccin.setBounds(9, 142, 72, 23);
		contentPane.add(lblDireccin);
		
		tfDireccion = new JTextField();
		tfDireccion.setFont(new Font("Verdana", Font.PLAIN, 14));
		tfDireccion.setBounds(115, 142, 457, 23);
		contentPane.add(tfDireccion);
		tfDireccion.setColumns(10);
		
		JLabel lblCPostal = new JLabel("Codi Postal:");
		lblCPostal.setFont(new Font("Verdana", Font.PLAIN, 14));
		lblCPostal.setBounds(9, 194, 104, 23);
		contentPane.add(lblCPostal);
		
		tfCPostal = new JTextField();
		tfCPostal.setFont(new Font("Verdana", Font.PLAIN, 14));
		tfCPostal.setBounds(150, 194, 53, 23);
		contentPane.add(tfCPostal);
		tfCPostal.setColumns(10);
		
		JLabel lblPoblacion = new JLabel("Poblaci\u00F3:");
		lblPoblacion.setFont(new Font("Verdana", Font.PLAIN, 14));
		lblPoblacion.setBounds(219, 194, 72, 23);
		contentPane.add(lblPoblacion);
		
		tfPoblacion = new JTextField();
		tfPoblacion.setFont(new Font("Verdana", Font.PLAIN, 14));
		tfPoblacion.setBounds(309, 194, 263, 23);
		contentPane.add(tfPoblacion);
		tfPoblacion.setColumns(10);
		
		JLabel lblMovil = new JLabel("M\u00F2bil:");
		lblMovil.setFont(new Font("Verdana", Font.PLAIN, 14));
		lblMovil.setBounds(9, 246, 44, 23);
		contentPane.add(lblMovil);
		
		tfMovil = new JTextField();
		tfMovil.setFont(new Font("Verdana", Font.PLAIN, 14));
		tfMovil.setBounds(66, 246, 86, 23);
		contentPane.add(tfMovil);
		tfMovil.setColumns(10);
		
		JLabel lblTelefono = new JLabel("Tel\u00E8fon:");
		lblTelefono.setFont(new Font("Verdana", Font.PLAIN, 14));
		lblTelefono.setBounds(163, 246, 68, 23);
		contentPane.add(lblTelefono);
		
		tfTelefono = new JTextField();
		tfTelefono.setFont(new Font("Verdana", Font.PLAIN, 14));
		tfTelefono.setBounds(242, 246, 86, 23);
		contentPane.add(tfTelefono);
		tfTelefono.setColumns(10);
		
		JLabel lblNacimiento = new JLabel("Data Naixement:");
		lblNacimiento.setFont(new Font("Verdana", Font.PLAIN, 14));
		lblNacimiento.setBounds(339, 246, 128, 23);
		contentPane.add(lblNacimiento);
		
		tfNacimiento = new JTextField();
		tfNacimiento.setFont(new Font("Verdana", Font.PLAIN, 14));
		tfNacimiento.setBounds(478, 246, 94, 23);
		contentPane.add(tfNacimiento);
		tfNacimiento.setColumns(10);
		
		JButton btnAceptar = new JButton("Acceptar");
		btnAceptar.addActionListener(this);
		btnAceptar.setFont(new Font("Verdana", Font.PLAIN, 14));
		btnAceptar.setBounds(328, 308, 104, 23);
		contentPane.add(btnAceptar);
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(this);
		btnCancelar.setFont(new Font("Verdana", Font.PLAIN, 14));
		btnCancelar.setBounds(455, 308, 104, 23);
		contentPane.add(btnCancelar);
		setFocusTraversalPolicy(new FocusTraversalOnArray(new Component[]{contentPane, lblNombre, tfNombre, lblApellidos, tfApellidos, lblNif, tfNIF, lblSexo, cbSexo, lblEmail, tfEmail, lblDireccin, tfDireccion, lblCPostal, tfCPostal, lblPoblacion, tfPoblacion, lblMovil, tfMovil, lblTelefono, tfTelefono, lblNacimiento, tfNacimiento, btnAceptar, btnCancelar}));
	}
	
	private Cliente asignarDatosCliente(){
		Cliente newCliente; 
		Date nacimiento = new Date();
		//nacimiento = java.sql.Date.valueOf(this.tfNacimiento.getText());
		newCliente = new Cliente(this.tfNombre.getText(), this.tfApellidos.getText(), this.tfNIF.getText(), this.cbSexo.getSelectedItem().toString(), this.tfDireccion.getText(), this.tfPoblacion.getText(), this.tfCPostal.getText(), this.tfTelefono.getText(), this.tfMovil.getText(), this.tfEmail.getText(), nacimiento);
		return newCliente;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		//boolean respuesta = false;
		Cliente newCliente;
		newCliente = asignarDatosCliente();
		bd.insertar_Cliente_db(newCliente);
		bd.cerrar_db();
		System.exit(0);
	}	

}
