package victor.donet.peluqueria.maida.formularios;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class PantallaClientes extends JFrame implements ActionListener{
	private static final long serialVersionUID = 1L;
	private JLabel lblNombre, lblApellidos, lblNif, lblSexo;
	private JLabel lblDireccion, lblPoblacion, lblCPostal, lblTelFijo;
	private JLabel lblMovil, lblEmail, lblFecAlta, lblFecNac;
	private JTextField txfNombre, txfApellidos, txfNif, txfDireccion, txfPoblacion;
	private JTextField txfCPostal, txfTelFijo, txfMovil, txfEmail, txfFecAlta, txfFecNac;
	private ButtonGroup btgSexo;
	private JRadioButton rbtHombre, rbtMujer;
	private JButton btnAceptar, btnCancelar;
	private JPanel pnlSexo;
	
	
	public PantallaClientes(){
		inicializarVariables();
	}
	
	private void inicializarVariables(){
		this.setSize(850, 350);
		this.setLayout(new GridLayout(7,2));

		this.lblNombre = new JLabel("Nombre:");
		this.add(lblNombre);
		this.txfNombre = new JTextField(25);
		this.txfNombre.setName("nombre");
		this.add(txfNombre);

		this.lblApellidos = new JLabel("Apellidos:");
		this.add(lblApellidos);
		this.txfApellidos = new JTextField(25);
		this.txfApellidos.setName("apellidos");
		this.add(txfApellidos);

		this.lblNif = new JLabel("NIF:");
		this.add(lblNif);
		this.txfNif = new JTextField(12);
		this.txfNif.setName("nif");
		this.add(txfNif);

		
		this.pnlSexo = new JPanel();
		this.lblSexo = new JLabel("Sexo:");
		this.add(lblSexo);
		btgSexo = new ButtonGroup();
		rbtHombre = new JRadioButton("Hombre",false);
		btgSexo.add(rbtHombre);
		pnlSexo.add(rbtHombre);
		rbtMujer = new JRadioButton("Mujer",true);
		btgSexo.add(rbtMujer);
		pnlSexo.add(rbtMujer);
		this.add(pnlSexo);

		this.lblDireccion = new JLabel("Direcci�n:");
		this.add(lblDireccion);
		this.txfDireccion = new JTextField(25);
		this.txfDireccion.setName("direccion");
		this.add(txfDireccion);

		this.lblPoblacion = new JLabel("Poblaci�n:");
		this.add(lblPoblacion);
		this.txfPoblacion = new JTextField(25);
		this.txfPoblacion.setName("poblacion");
		this.add(txfPoblacion);

		this.lblCPostal = new JLabel("C�digo Postal:");
		this.add(lblCPostal);
		this.txfCPostal = new JTextField(25);
		this.txfCPostal.setName("codigoPostal");
		this.add(txfCPostal);

		this.lblTelFijo = new JLabel("Tel�fono Fijo:");
		this.add(lblTelFijo);
		this.txfTelFijo = new JTextField(25);
		this.txfTelFijo.setName("telefono");
		this.add(txfTelFijo);

		this.lblMovil = new JLabel("M�vil:");
		this.add(lblMovil);
		this.txfMovil = new JTextField(25);
		this.txfMovil.setName("movil");
		this.add(txfMovil);

		this.lblEmail = new JLabel("email:");
		this.add(lblEmail);
		this.txfEmail = new JTextField(25);
		this.txfEmail.setName("email");
		this.add(txfEmail);

		this.lblFecAlta = new JLabel("Fecha de Alta:");
		this.add(lblFecAlta);
		this.txfFecAlta = new JTextField(25);
		this.txfFecAlta.setName("alta");
		this.add(txfFecAlta);

		this.lblFecNac = new JLabel("Fecha de Nacimiento:");
		this.add(lblFecNac);
		this.txfFecNac = new JTextField(25);
		this.txfFecNac.setName("nacimiento");
		this.add(txfFecNac);
		
		this.btnAceptar = new JButton("Aceptar");
		this.btnAceptar.setName("btnAceptar");
		this.btnAceptar.addActionListener(this);
		this.add(btnAceptar);
		this.btnCancelar = new JButton("Cancelar");
		this.btnCancelar.setName("btnCacelar");
		this.btnCancelar.addActionListener(this);
		this.add(btnCancelar);
	}

	@Override
	public void actionPerformed(ActionEvent evento) {
		JButton btnPulsado = (JButton) evento.getSource();
		switch (btnPulsado.getName()){
		case "btnAceptar" :
			break;
		case "btnCancelar" :
			break;
		}		
	}
}
