package victor.donet.peluqueria.maida.formularios;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.sql.ResultSet;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import victor.donet.peluqueria.maida.clases.BaseDatos;

public class Tintes extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTable tabla;
	private DefaultTableModel dtmTabla;
    private JScrollPane scrollTabla;
	private BaseDatos bd;
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Tintes frame = new Tintes();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Tintes() {
		bd = new BaseDatos();
		
		setTitle("Perruqueria Maida - Cortes y Tintes Aplicados");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 700, 500);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(154, 205, 50));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblCliente = new JLabel("Cliente:");
		lblCliente.setFont(new Font("Verdana", Font.PLAIN, 14));
		lblCliente.setBounds(33, 26, 74, 20);
		contentPane.add(lblCliente);
		
		JLabel lblNewLabel = new JLabel("Cliente");
		lblNewLabel.setFont(new Font("Verdana", Font.BOLD, 14));
		lblNewLabel.setBounds(117, 26, 336, 20);
		contentPane.add(lblNewLabel);
		
		tabla = new JTable();
		scrollTabla= new JScrollPane();
		// llenamos el modelo de tabla
		dtmTabla = new DefaultTableModel(null, this.getColumnas());
		this.setFilas();

		tabla.setFont(new Font("Verdana", Font.PLAIN, 14));
		tabla.setModel(dtmTabla);
		scrollTabla.add(tabla);
		contentPane.add(scrollTabla);
		scrollTabla.setViewportView(tabla);
		
/*		tabla.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Fecha", "Tinte", "Color", "Observaciones"
			}
		) {
			Class[] columnTypes = new Class[] {
				String.class, String.class, Object.class, String.class
			};
			public Class getColumnClass(int columnIndex) {
				return columnTypes[columnIndex];
			}
		});
		*/
		tabla.getColumnModel().getColumn(0).setMaxWidth(75);
		tabla.getColumnModel().getColumn(1).setPreferredWidth(119);
		tabla.getColumnModel().getColumn(2).setPreferredWidth(125);
		tabla.getColumnModel().getColumn(3).setPreferredWidth(269);
		tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		tabla.setBounds(22, 57, 632, 326);
//		contentPane.add(tabla);
		
		JButton btnNewButton = new JButton("Salir");
		btnNewButton.setFont(new Font("Verdana", Font.PLAIN, 14));
		btnNewButton.setBounds(509, 394, 145, 37);
		contentPane.add(btnNewButton);
        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
	}
	
    //Encabezados de la tabla
    private String[] getColumnas()
    {
    	String columna[] = new String[] {"Fecha", "Tinte", "Color", "Observaciones"};
    	return columna;
    }
    
    private void setFilas()
    {
    	ResultSet rs = null;
    	rs = bd.consultar_db("SELECT Tintes.Fecha, Tintes.Tinte, Tintes.Color, Tintes.Observaciones FROM Tintes WHERE (((Tintes.idCliente)=1));");

        Object datos[]=new Object[4]; //Numero de columnas de la tabla

        try {
            while (rs.next()) {
                for (int i = 0; i < 4; i++) {
                        datos[i] = rs.getObject(i + 1);
                }
                dtmTabla.addRow(datos);
            }
            rs.close();
        } catch (Exception e) {
			JOptionPane.showMessageDialog(null, "setFilas(): No se logr� establecer conexi�n con la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
}
